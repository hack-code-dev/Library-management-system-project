<?php
/**
 * Image_Exception
 * 
 * @author Rob Keplin
 * @link http://www.robkeplin.com
 **/

class Image_Exception
    extends Exception
{ }